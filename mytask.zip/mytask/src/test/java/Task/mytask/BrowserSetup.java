package Task.mytask;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserSetup {

	static WebDriver driver;
	LandingPage lpage;
	
	
	@BeforeTest
	public void setup() {
		
	// initializing driver and launching URL	
    WebDriverManager.chromedriver().setup();
    driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	driver.get("https://www.autohero.com/de/search/");
	driver.manage().window().maximize();
	   
	}
	
	@Test(priority = 1)
	public void makeUserSelectionAndValidateUserSelection() {
		lpage=new LandingPage(driver);
		
		// Configuring cookies
		lpage.onclick(lpage.configureCookies);
		lpage.onclick(lpage.saveCookies);
		
		//Selecting required filters from the filter dropdowns.
		lpage.onclick(lpage.markeModell);
		lpage.onclick(lpage.volkswagen);
		lpage.onclick(lpage.golf);
		lpage.onclick(lpage.kilometer);
		lpage.onSelect(lpage.rangeStart, "Beliebig");
		lpage.onSelect(lpage.rangeEnd, "25.000 km");
		lpage.onclick(lpage.kilometer);
		
		//Asserting selected filters are reflecting in the filter sections.
		Assert.assertEquals(lpage.getText(lpage.carName), "Volkswagen");
		Assert.assertEquals(lpage.getText(lpage.modelName), "Golf");
		Assert.assertEquals(lpage.getText(lpage.carMilage), "Bis 25.000 km");
	}
	
	@AfterTest
	public void cleanUp() {
	//closing driver
	driver.quit();
	}

}
