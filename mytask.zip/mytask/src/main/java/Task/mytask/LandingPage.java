package Task.mytask;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class LandingPage {

	WebDriver driver;
	
	By configureCookies = By.xpath("//button[text()='Konfigurieren']");
	By saveCookies = By.xpath("//button[text()='Auswahl speichern']");
	
	// Selection Criteria WebElements
	By markeModell = By.xpath("//span[text()='Marke & Modell']");
	By volkswagen = By.xpath("(//input[@value='Volkswagen'])[1]");
	By golf = By.xpath("(//input[@value='Golf'])[1]");
	
	By kilometer = By.xpath("//span[text()='Kilometer']"); 
	By rangeStart =By.xpath("//select[@id='rangeStart' and @data-qa-selector='select-mileage-from']");
	By rangeEnd =By.xpath("//select[@id='rangeEnd' and @data-qa-selector='select-mileage-to']");
	
	//filter section WebElements
	By carName = By.xpath("//button[contains(text(),'Volkswagen')]");
	By modelName = By.xpath("//button[contains(text(),'Golf')]");
	By carMilage = By.xpath("//button[contains(text(),'Kilometer')]");
	
	
	public LandingPage(WebDriver driver) {
	
	   this.driver = driver;
	}
	
	//Method to perform Click operation
	public void onclick(By ele) {
	
	   driver.findElement(ele).click();
	}
	
	//Method to perform Select operation from DropDown
	public void onSelect(By ele,String text) {
		
	   Select range = new Select(driver.findElement(ele));
	   range.selectByVisibleText(text);
	}
	
	//Method to read text from the WebElement
	public String getText(By ele) {
		
	    return driver.findElement(ele).getText().split(":")[1].trim();
	}
	
	
}

