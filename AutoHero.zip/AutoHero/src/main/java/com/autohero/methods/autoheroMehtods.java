package com.autohero.methods;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.autohero.init.Initautohero;
import com.selenium.util.WebDriverUtil;

public class autoheroMehtods extends Initautohero {

	public String checkresults(String sLoanAmmount) throws Exception {
		
		/* 
		 * These are locators which in the used in the test
		 * */
		String sBrand = "//button[@id='carMakeFilter']";
		String sModel = "//ul[@class='list___2iBtR']//input[@value='Volkswagen']";
		String sMake = "//input[@value='Golf']";
		String sBasic = "//button[@id='basicFilter']";
		String sKilometer = "//div[@class='row___2pUNR']//div[@class='wrapper___3EMu3']//div[@class='rangeContainer___1mgKq']//div//select[@id='rangeEnd']";
		String sModelValueCount = "//h2[contains(@class,'title___1TYYE')]";
		
		String sKmValues = "//li[contains(@data-qa-selector,'spec-mileage')]";
		
				
		//Brand link in home page
		webdriverUtil.getWebElement(driver, sBrand).click();
		//explicit wait after brand link 				
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sModel))).click();
		
		//WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(sMake))).click();
		
		// Thread.sleep(10000);
		
		WebElement svgObj = webdriverUtil.getWebElement(driver, sBasic);
		Actions actionBuilder = new Actions(driver);
		actionBuilder.click(svgObj).build().perform();
		
	
		//Select the 25000 km options 
		Select sel = new Select(webdriverUtil.getWebElement(driver, sKilometer));
		sel.selectByIndex(2);
		
		//Verifying the product name from application and dispalying 
		
		String product = webdriverUtil.getWebElement(driver, sModelValueCount).getText();
		System.out.println(product);
		
		//Verifying kms values of brand
		List<WebElement> productcount = driver.findElements(By.xpath("//h2[contains(@class,'title___1TYYE')]"));
		
		//System.out.println(productcount.size());
		
		List<WebElement> kilometervalues = driver.findElements(By.xpath("//li[contains(@data-qa-selector,'spec-mileage')]"));
		
		for(int i=0;i<kilometervalues.size();i++)
		{
		
			System.out.println(kilometervalues.get(i).getText());
		}
				
		logger.info("Done!");		
		return "done";
		
	}
}
