package com.autohero.init;

import java.time.Duration;

import org.junit.BeforeClass;

import com.autohero.methods.autoheroMehtods;
import com.selenium.base.InitWebDriver;
import com.selenium.util.WebDriverUtil;

public class Initautohero extends InitWebDriver {
	
	/* 
	 * This class is used for initilization of setup 
	 */

	protected static final String BASE_URL = lookuputil.getConfig("BASE_URL").trim();
	protected static autoheroMehtods autoheroMehtods;
	protected static WebDriverUtil webdriverUtil = null;
	 @BeforeClass
	 public static void setUpInit() throws Exception
	   {
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(25));		 
		 autoheroMehtods = new autoheroMehtods();
		 webdriverUtil = new WebDriverUtil();
	   }
}
