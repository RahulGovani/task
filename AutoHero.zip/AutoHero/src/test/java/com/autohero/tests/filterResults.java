package com.autohero.tests;

import java.io.File;
import java.util.logging.Level;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.autohero.init.Initautohero;


public class filterResults extends Initautohero{

	private static String  sRet = null;
	
	@BeforeClass
	public static void setup() throws Exception {
		// driver.manage().timeouts().implicitlyWait(SMALL_SLEEP, TimeUnit.)
		try {
			System.out.println("Before driver.get...");
			driver.get(BASE_URL);
			System.out.println("current url: \t" + driver.getCurrentUrl());
			Thread.sleep(10000);
			driver.findElement(By.xpath("//button[@type='submit']")).click();
		} catch (Exception e) {
			clogger.log(Level.SEVERE, e.getMessage(), e);
			clogger.info("Exiting execution!!! as base setup itself failed.");
			e.printStackTrace();
			driver.quit();
			System.exit(1);
		}
	}
	
	@Test
	public void test_filterResults() throws Exception{
		sRet = autoheroMehtods.checkresults("Volkswagen Golf");
		System.out.println("Returned : "+sRet);
		logger.info("After executing test case returned string :"+sRet);
		Assert.assertEquals("done", sRet);
		
	}

	
	@AfterClass
	public static void teardown() throws Exception {
		try {
			driver.quit();
		} catch (Exception e) {
			clogger.info(e.getMessage());
		} 
	}
	
}
